print('Running foo/txt.py')
