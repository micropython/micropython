print('Running foo/__init__.py')
